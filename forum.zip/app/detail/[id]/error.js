'use client';

//NOTE: 에러페이지는 클라이언트 컴포넌트로만 만들어야함

export default function Loading({ error, reset }) {
  return <div>에러남</div>;
}
