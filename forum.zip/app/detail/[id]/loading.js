export default function Loading() {
  return <div>로딩중</div>;
}
